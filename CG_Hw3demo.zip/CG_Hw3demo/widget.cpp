#include "widget.h"
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

Widget::Widget(QWidget *parent)
    : QOpenGLWidget(parent)
{
    timer = new QTimer(this);
    timer->start(16);
    connect(timer, SIGNAL(timeout()), this, SLOT(update()));
}

Widget::~Widget()
{
    delete this->timer;
}

void Widget::initializeGL()
{
    initializeOpenGLFunctions();
    initializeShaders();

    glViewport(0, 0, width(), height());
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glDisable(GL_DEPTH_TEST);
}

void Widget::resizeGL(int w, int h)
{
    glViewport(0, 0, w, h);
    update();
}

/***********************************   Demo Implementation   ************************************/

// You can delete demo codes and then implement your codes, or modify demo codes directly.

static int greenValue = 0; // use for demo implementation

void Widget::paintGL()
{
    // Demo Implementation
    glClear(GL_COLOR_BUFFER_BIT);
    glUseProgram(program);

    // Bind uniform
    int vertexColorLocation = glGetUniformLocation(program, "inputColor");
    greenValue = (greenValue + 1) % 256;
    glUniform4f(vertexColorLocation, 0.0f, float(greenValue / 255.0), 0.0f, 1.0f);

    // Draw a demo triangle
    glBegin(GL_TRIANGLES);
    glVertex4f(-0.5f, -0.5f, 0.0f, 1.0f);
    glVertex4f(0.5f, -0.5f, 0.0f, 1.0f);
    glVertex4f(0.0f, 0.5f, 0.0f, 1.0f);
    glEnd();

    glFlush();
}

void Widget::initializeShaders()
{
    // Read shader files and Convert to const char* type
    std::ifstream vertexShaderFile;
    std::ifstream fragmentShaderFile;

    // NOTICE: modify the file paths below
    vertexShaderFile.open("/home/dm/Hw3demo/demo_triangle.vert");
    fragmentShaderFile.open("/home/dm/Hw3demo/demo_triangle.frag");

    std::stringstream vertexShaderStream;
    std::stringstream fragmentShaderStream;

    vertexShaderStream << vertexShaderFile.rdbuf();
    fragmentShaderStream << fragmentShaderFile.rdbuf();

    vertexShaderFile.close();
    fragmentShaderFile.close();

    std::string vertexShaderCode = vertexShaderStream.str();
    std::string fragmentShaderCode = fragmentShaderStream.str();

    const char* vertexShaderSource = vertexShaderCode.c_str();
    const char* fragmentShaderSource = fragmentShaderCode.c_str();

    // If we've read the shader files successfully, the shader codes will be displayed below.
    std::cout << "vertex shader source : " << vertexShaderSource << std::endl;
    std::cout << "fragment shader source : " << fragmentShaderSource << std::endl;

    // Create and Compile shaders
    vertexShader = glCreateShader(GL_VERTEX_SHADER);
    fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);

    glShaderSource(vertexShader, 1, &vertexShaderSource, nullptr);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, nullptr);

    glCompileShader(vertexShader);
    glCompileShader(fragmentShader);

    // Create and Link shader program
    program = glCreateProgram();
    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);

    glLinkProgram(program);

    // If we've linked our shader program successfully, the success code will be 1, or it will be 0 and print error info.
    int success;
    glGetProgramiv(program, GL_LINK_STATUS, &success);
    std::cout << "program link : " << success << std::endl;
    if (!success) {
        char info[512];
        glGetProgramInfoLog(program, 512, nullptr, info);
        std::cout << info << std::endl;
    }

}

/*************************************************************************************************/
