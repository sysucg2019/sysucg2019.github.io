#include "myglwidget.h"

MyGLWidget::MyGLWidget(QWidget *parent)
    : QWidget(parent)
{

}

MyGLWidget::~MyGLWidget()
{

}

void MyGLWidget::initializeGL()
{

}

void MyGLWidget::paintGL()
{

}

void MyGLWidget::resizeGL(int width, int height)
{

}
